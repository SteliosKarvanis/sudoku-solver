Arquivo zip gerado em: 17/10/2021 19:19:41 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Laboratório EX2 - Sudoku